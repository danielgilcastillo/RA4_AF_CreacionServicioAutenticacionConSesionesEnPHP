<?php
session_start();

// Redirigir a permisos.php si el usuario no está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: permisos.php");
    exit;
}

// Datos del usuario
$usuario = $_SESSION['usuario'];
$horaActual = date("H:i:s");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bienvenida</title>
</head>
<body>
    <h1>Bienvenido, <?= htmlspecialchars($usuario) ?>!</h1>
    <p>Hora actual: <?= $horaActual ?></p>
    <p>Estamos encantados de tenerte aquí. ¡Disfruta tu estancia!</p>
    <a href="logout.php">Cerrar sesión</a>
</body>
</html>