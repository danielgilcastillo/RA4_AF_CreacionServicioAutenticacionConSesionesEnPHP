<?php
// Inicio de sesión
session_start();

// Lista de usuarios válidos
$usuarios = [
    "admin" => "1234",
    "usuario" => "abcd"
];

// Manejo del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validación de credenciales
    if (isset($usuarios[$username]) && $usuarios[$username] === $password) {
        $_SESSION['usuario'] = $username; // Guardar el usuario en la sesión
        header("Location: bienvenida.php");
        exit;
    } else {
        $error = "Credenciales inválidas";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h1>Iniciar Sesión</h1>
    <form method="POST" action="">
        <label for="username">Usuario:</label>
        <input type="text" id="username" name="username" required>
        <br>
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>
        <br>
        <button type="submit">Iniciar sesión</button>
    </form>
    <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
</body>
</html>