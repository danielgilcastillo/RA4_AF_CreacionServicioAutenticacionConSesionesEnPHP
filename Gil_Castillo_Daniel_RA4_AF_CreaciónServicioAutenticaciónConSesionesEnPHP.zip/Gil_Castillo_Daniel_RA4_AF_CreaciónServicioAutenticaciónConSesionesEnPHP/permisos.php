<!DOCTYPE html>
<html>
<head>
    <title>Sin permisos</title>
</head>
<body>
    <h1>No tienes permisos</h1>
    <p>No estás autorizado para acceder a esta página. Por favor, inicia sesión primero.</p>
    <a href="login.php">Volver al login</a>
</body>
</html>